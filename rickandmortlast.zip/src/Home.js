import React from "react";
import { Typography } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { Link } from "@material-ui/core";
import { Link as RouterLink } from "react-router-dom";

export default function Home() {
  const classes = useStyles();

  return (
    <div>
      <h1> I'm Pickle Rick!</h1>

      <section className={classes.main}>
        <Typography variant="h5">Where are we going?</Typography>
        <Typography variant="body1">
          {" "}
          <Link component={RouterLink} to="/episodes">
            Episodes
          </Link>{" "}
          or{" "}
          <Link component={RouterLink} to="/characters">
            Characters
          </Link>
        </Typography>
      </section>
    </div>
  );
}

const useStyles = makeStyles((theme) => ({
  main: {
    margin: "0 auto",
    padding: "16px"
  },
  menu: {
    margin: "0 auto",
    display: "flex",
    justifyContent: "center",
    backgroundColor: "#CCC",
    "& button": {
      margin: theme.spacing(1)
    }
  }
}));

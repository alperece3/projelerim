import React from "react";
import Episodes from "./Episodes";
import Episode from "./Episode";
import Characters from "./Characters";
import Character from "./Character";
import Home from "./Home";
import "./Layout.css";
import { Link, Button } from "@material-ui/core";
import { Switch, Route, Link as RouterLink } from "react-router-dom";

export default function Layout() {
  return (
    <div className="App">
      <nav className="menu">
        <Link component={RouterLink} to="/episodes">
          <Button color="Green">
            <h1>Episodes</h1>
          </Button>
        </Link>
        <Link component={RouterLink} to="/characters">
          <Button color="Green">
            <h1>Characters</h1>
          </Button>
        </Link>
      </nav>
      <main className="main">
        <Switch>
          <Route exact path="/episodes">
            <Episodes />
          </Route>
          <Route exact path="/episodes/:episodeId">
            <Episode />
          </Route>
          <Route exact path="/characters">
            <Characters />
          </Route>
          <Route exact path="/characters/:characterId">
            <Character />
          </Route>
          <Route path="/">
            <Home />
          </Route>
        </Switch>
      </main>
    </div>
  );
}

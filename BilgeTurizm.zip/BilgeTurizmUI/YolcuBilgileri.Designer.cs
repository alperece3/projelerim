﻿namespace BilgeTurizmUI
{
    partial class YolcuBilgileri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDevamEt = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.gidisBilgiPaneli = new System.Windows.Forms.FlowLayoutPanel();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.donusBilgiPaneli = new System.Windows.Forms.FlowLayoutPanel();
            this.lblDonus = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.grpDonusLabels = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.chkSigorta = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lblSigorta = new System.Windows.Forms.Label();
            this.grpDonusLabels.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDevamEt
            // 
            this.btnDevamEt.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnDevamEt.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnDevamEt.ForeColor = System.Drawing.Color.White;
            this.btnDevamEt.Location = new System.Drawing.Point(828, 403);
            this.btnDevamEt.Name = "btnDevamEt";
            this.btnDevamEt.Size = new System.Drawing.Size(118, 42);
            this.btnDevamEt.TabIndex = 4;
            this.btnDevamEt.Text = "DEVAM ET";
            this.btnDevamEt.UseVisualStyleBackColor = false;
            this.btnDevamEt.Click += new System.EventHandler(this.btnDevamEt_Click);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.label6.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(9, 15);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(937, 24);
            this.label6.TabIndex = 31;
            this.label6.Text = "Gidiş Yolcu Bilgileri";
            // 
            // gidisBilgiPaneli
            // 
            this.gidisBilgiPaneli.AutoScroll = true;
            this.gidisBilgiPaneli.Location = new System.Drawing.Point(15, 72);
            this.gidisBilgiPaneli.Name = "gidisBilgiPaneli";
            this.gidisBilgiPaneli.Size = new System.Drawing.Size(931, 124);
            this.gidisBilgiPaneli.TabIndex = 32;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(17, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 14);
            this.label8.TabIndex = 33;
            this.label8.Text = "Koltuk No";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(82, 56);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 13);
            this.label10.TabIndex = 34;
            this.label10.Text = "TC Kimlik Numarası";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(186, 57);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 13);
            this.label11.TabIndex = 35;
            this.label11.Text = "Ad ";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(399, 56);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 13);
            this.label12.TabIndex = 35;
            this.label12.Text = "E-Mail Adresi";
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(505, 56);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 13);
            this.label13.TabIndex = 35;
            this.label13.Text = "Telefon No.";
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(600, 56);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(121, 13);
            this.label14.TabIndex = 35;
            this.label14.Text = "Cinsiyet";
            // 
            // donusBilgiPaneli
            // 
            this.donusBilgiPaneli.AutoScroll = true;
            this.donusBilgiPaneli.Location = new System.Drawing.Point(12, 267);
            this.donusBilgiPaneli.Name = "donusBilgiPaneli";
            this.donusBilgiPaneli.Size = new System.Drawing.Size(934, 124);
            this.donusBilgiPaneli.TabIndex = 37;
            // 
            // lblDonus
            // 
            this.lblDonus.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.lblDonus.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDonus.ForeColor = System.Drawing.Color.White;
            this.lblDonus.Location = new System.Drawing.Point(11, 207);
            this.lblDonus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDonus.Name = "lblDonus";
            this.lblDonus.Size = new System.Drawing.Size(935, 24);
            this.lblDonus.TabIndex = 36;
            this.lblDonus.Text = "Dönüş Yolcu Bilgileri";
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(293, 56);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 13);
            this.label15.TabIndex = 44;
            this.label15.Text = "Soyad";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(282, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 13);
            this.label1.TabIndex = 51;
            this.label1.Text = "Soyad";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(589, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 13);
            this.label2.TabIndex = 47;
            this.label2.Text = "Cinsiyet";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(494, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 48;
            this.label3.Text = "Telefon No.";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(388, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 13);
            this.label4.TabIndex = 49;
            this.label4.Text = "E-Mail Adresi";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(175, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 13);
            this.label5.TabIndex = 50;
            this.label5.Text = "Ad ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(71, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 13);
            this.label7.TabIndex = 46;
            this.label7.Text = "TC Kimlik Numarası";
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.Location = new System.Drawing.Point(6, 10);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 14);
            this.label16.TabIndex = 45;
            this.label16.Text = "Koltuk No";
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(727, 56);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(121, 13);
            this.label17.TabIndex = 52;
            this.label17.Text = "Yemek Menüsü";
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(716, 11);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(121, 13);
            this.label18.TabIndex = 53;
            this.label18.Text = "Yemek Menüsü";
            // 
            // grpDonusLabels
            // 
            this.grpDonusLabels.Controls.Add(this.label19);
            this.grpDonusLabels.Controls.Add(this.label16);
            this.grpDonusLabels.Controls.Add(this.label18);
            this.grpDonusLabels.Controls.Add(this.label7);
            this.grpDonusLabels.Controls.Add(this.label5);
            this.grpDonusLabels.Controls.Add(this.label1);
            this.grpDonusLabels.Controls.Add(this.label4);
            this.grpDonusLabels.Controls.Add(this.label2);
            this.grpDonusLabels.Controls.Add(this.label3);
            this.grpDonusLabels.Location = new System.Drawing.Point(13, 234);
            this.grpDonusLabels.Name = "grpDonusLabels";
            this.grpDonusLabels.Size = new System.Drawing.Size(933, 27);
            this.grpDonusLabels.TabIndex = 54;
            this.grpDonusLabels.TabStop = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(835, 10);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(38, 13);
            this.label19.TabIndex = 57;
            this.label19.Text = "Çocuk";
            // 
            // chkSigorta
            // 
            this.chkSigorta.AutoSize = true;
            this.chkSigorta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.chkSigorta.Location = new System.Drawing.Point(12, 417);
            this.chkSigorta.Name = "chkSigorta";
            this.chkSigorta.Size = new System.Drawing.Size(138, 22);
            this.chkSigorta.TabIndex = 55;
            this.chkSigorta.Text = "Sigorta İstiyorum";
            this.chkSigorta.UseVisualStyleBackColor = true;
            this.chkSigorta.CheckedChanged += new System.EventHandler(this.chkSigorta_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(854, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 13);
            this.label9.TabIndex = 56;
            this.label9.Text = "Çocuk";
            // 
            // lblSigorta
            // 
            this.lblSigorta.AutoSize = true;
            this.lblSigorta.Location = new System.Drawing.Point(156, 422);
            this.lblSigorta.Name = "lblSigorta";
            this.lblSigorta.Size = new System.Drawing.Size(209, 13);
            this.lblSigorta.TabIndex = 57;
            this.lblSigorta.Text = "NOT:  Sigorta bedeli bilet başına 20 TL\'dir..";
            this.lblSigorta.Visible = false;
            // 
            // YolcuBilgileri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(955, 457);
            this.Controls.Add(this.lblSigorta);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.chkSigorta);
            this.Controls.Add(this.grpDonusLabels);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.donusBilgiPaneli);
            this.Controls.Add(this.lblDonus);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.gidisBilgiPaneli);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnDevamEt);
            this.Name = "YolcuBilgileri";
            this.Text = "Yolcu Bilgileri Giriş Ekranı";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.YolcuBilgileri_FormClosed);
            this.Load += new System.EventHandler(this.YolcuBilgileri_Load);
            this.grpDonusLabels.ResumeLayout(false);
            this.grpDonusLabels.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Button btnDevamEt;
        public System.Windows.Forms.Label label6;
        private System.Windows.Forms.FlowLayoutPanel gidisBilgiPaneli;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.FlowLayoutPanel donusBilgiPaneli;
        public System.Windows.Forms.Label lblDonus;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox grpDonusLabels;
        private System.Windows.Forms.CheckBox chkSigorta;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblSigorta;
    }
}
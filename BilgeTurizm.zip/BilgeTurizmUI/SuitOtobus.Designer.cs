﻿namespace BilgeTurizmUI
{
    partial class SuitOtobus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SuitOtobus));
            this.label1 = new System.Windows.Forms.Label();
            this.btnDevamEt = new System.Windows.Forms.Button();
            this.lblOrtaKapi = new System.Windows.Forms.Label();
            this.lblOnKapi = new System.Windows.Forms.Label();
            this.lblSofor = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.lblSecili = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.pictureBoxErkek = new System.Windows.Forms.PictureBox();
            this.pictureBoxKadin = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.grpSuitOtobus = new System.Windows.Forms.GroupBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxErkek)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKadin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grpSuitOtobus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(9, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(520, 24);
            this.label1.TabIndex = 29;
            this.label1.Text = "Seçtiğiniz Koltuklar:";
            // 
            // btnDevamEt
            // 
            this.btnDevamEt.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnDevamEt.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnDevamEt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDevamEt.Location = new System.Drawing.Point(370, 336);
            this.btnDevamEt.Margin = new System.Windows.Forms.Padding(2);
            this.btnDevamEt.Name = "btnDevamEt";
            this.btnDevamEt.Size = new System.Drawing.Size(158, 43);
            this.btnDevamEt.TabIndex = 36;
            this.btnDevamEt.Text = "DEVAM ET";
            this.btnDevamEt.UseVisualStyleBackColor = false;
            this.btnDevamEt.Click += new System.EventHandler(this.btnDevamEt_Click);
            // 
            // lblOrtaKapi
            // 
            this.lblOrtaKapi.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblOrtaKapi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOrtaKapi.Location = new System.Drawing.Point(270, 36);
            this.lblOrtaKapi.Name = "lblOrtaKapi";
            this.lblOrtaKapi.Size = new System.Drawing.Size(41, 25);
            this.lblOrtaKapi.TabIndex = 43;
            this.lblOrtaKapi.Text = "Kapı";
            this.lblOrtaKapi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOnKapi
            // 
            this.lblOnKapi.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblOnKapi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOnKapi.Location = new System.Drawing.Point(31, 36);
            this.lblOnKapi.Name = "lblOnKapi";
            this.lblOnKapi.Size = new System.Drawing.Size(41, 25);
            this.lblOnKapi.TabIndex = 42;
            this.lblOnKapi.Text = "Kapı";
            this.lblOnKapi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSofor
            // 
            this.lblSofor.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblSofor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSofor.Location = new System.Drawing.Point(31, 135);
            this.lblSofor.Name = "lblSofor";
            this.lblSofor.Size = new System.Drawing.Size(41, 50);
            this.lblSofor.TabIndex = 41;
            this.lblSofor.Text = "Şoför";
            this.lblSofor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.Color.Lime;
            this.label43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label43.ForeColor = System.Drawing.Color.Red;
            this.label43.Location = new System.Drawing.Point(484, 201);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(25, 30);
            this.label43.TabIndex = 51;
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSecili
            // 
            this.lblSecili.BackColor = System.Drawing.Color.White;
            this.lblSecili.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSecili.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblSecili.Location = new System.Drawing.Point(470, 238);
            this.lblSecili.Name = "lblSecili";
            this.lblSecili.Size = new System.Drawing.Size(39, 15);
            this.lblSecili.TabIndex = 50;
            this.lblSecili.Text = "Seçili";
            this.lblSecili.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label47.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label47.Location = new System.Drawing.Point(421, 238);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(44, 15);
            this.label47.TabIndex = 49;
            this.label47.Text = "Kadın";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label48.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label48.Location = new System.Drawing.Point(366, 238);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(48, 15);
            this.label48.TabIndex = 48;
            this.label48.Text = "Erkek";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label49.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label49.Location = new System.Drawing.Point(326, 238);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(39, 15);
            this.label49.TabIndex = 47;
            this.label49.Text = "Boş";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label44.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label44.Location = new System.Drawing.Point(340, 201);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(25, 30);
            this.label44.TabIndex = 46;
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBoxErkek
            // 
            this.pictureBoxErkek.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxErkek.Image")));
            this.pictureBoxErkek.Location = new System.Drawing.Point(383, 201);
            this.pictureBoxErkek.Name = "pictureBoxErkek";
            this.pictureBoxErkek.Size = new System.Drawing.Size(30, 30);
            this.pictureBoxErkek.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxErkek.TabIndex = 52;
            this.pictureBoxErkek.TabStop = false;
            // 
            // pictureBoxKadin
            // 
            this.pictureBoxKadin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxKadin.BackgroundImage")));
            this.pictureBoxKadin.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxKadin.Image")));
            this.pictureBoxKadin.Location = new System.Drawing.Point(432, 201);
            this.pictureBoxKadin.Name = "pictureBoxKadin";
            this.pictureBoxKadin.Size = new System.Drawing.Size(30, 30);
            this.pictureBoxKadin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxKadin.TabIndex = 53;
            this.pictureBoxKadin.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(78, 135);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 54;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "";
            this.pictureBox1.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // grpSuitOtobus
            // 
            this.grpSuitOtobus.Controls.Add(this.pictureBox30);
            this.grpSuitOtobus.Controls.Add(this.pictureBox29);
            this.grpSuitOtobus.Controls.Add(this.pictureBox28);
            this.grpSuitOtobus.Controls.Add(this.pictureBox27);
            this.grpSuitOtobus.Controls.Add(this.pictureBox26);
            this.grpSuitOtobus.Controls.Add(this.pictureBox25);
            this.grpSuitOtobus.Controls.Add(this.pictureBox24);
            this.grpSuitOtobus.Controls.Add(this.pictureBox23);
            this.grpSuitOtobus.Controls.Add(this.pictureBox22);
            this.grpSuitOtobus.Controls.Add(this.pictureBox21);
            this.grpSuitOtobus.Controls.Add(this.pictureBox20);
            this.grpSuitOtobus.Controls.Add(this.pictureBox19);
            this.grpSuitOtobus.Controls.Add(this.pictureBox18);
            this.grpSuitOtobus.Controls.Add(this.pictureBox17);
            this.grpSuitOtobus.Controls.Add(this.pictureBox16);
            this.grpSuitOtobus.Controls.Add(this.pictureBox15);
            this.grpSuitOtobus.Controls.Add(this.pictureBox14);
            this.grpSuitOtobus.Controls.Add(this.pictureBox13);
            this.grpSuitOtobus.Controls.Add(this.pictureBox12);
            this.grpSuitOtobus.Controls.Add(this.pictureBox11);
            this.grpSuitOtobus.Controls.Add(this.pictureBox10);
            this.grpSuitOtobus.Controls.Add(this.pictureBox9);
            this.grpSuitOtobus.Controls.Add(this.pictureBox8);
            this.grpSuitOtobus.Controls.Add(this.pictureBox7);
            this.grpSuitOtobus.Controls.Add(this.pictureBox6);
            this.grpSuitOtobus.Controls.Add(this.pictureBox5);
            this.grpSuitOtobus.Controls.Add(this.pictureBox4);
            this.grpSuitOtobus.Controls.Add(this.pictureBox3);
            this.grpSuitOtobus.Controls.Add(this.pictureBox2);
            this.grpSuitOtobus.Controls.Add(this.pictureBox1);
            this.grpSuitOtobus.Controls.Add(this.pictureBoxKadin);
            this.grpSuitOtobus.Controls.Add(this.pictureBoxErkek);
            this.grpSuitOtobus.Controls.Add(this.label44);
            this.grpSuitOtobus.Controls.Add(this.label49);
            this.grpSuitOtobus.Controls.Add(this.label48);
            this.grpSuitOtobus.Controls.Add(this.label47);
            this.grpSuitOtobus.Controls.Add(this.lblSecili);
            this.grpSuitOtobus.Controls.Add(this.label43);
            this.grpSuitOtobus.Controls.Add(this.lblSofor);
            this.grpSuitOtobus.Controls.Add(this.lblOnKapi);
            this.grpSuitOtobus.Controls.Add(this.lblOrtaKapi);
            this.grpSuitOtobus.Font = new System.Drawing.Font("Lucida Sans Unicode", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grpSuitOtobus.Location = new System.Drawing.Point(10, 41);
            this.grpSuitOtobus.Name = "grpSuitOtobus";
            this.grpSuitOtobus.Size = new System.Drawing.Size(532, 263);
            this.grpSuitOtobus.TabIndex = 11;
            this.grpSuitOtobus.TabStop = false;
            this.grpSuitOtobus.Text = "Suit Otobüs Krokisi";
            // 
            // pictureBox30
            // 
            this.pictureBox30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox30.Location = new System.Drawing.Point(497, 36);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(25, 25);
            this.pictureBox30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox30.TabIndex = 54;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.Tag = "";
            this.pictureBox30.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox29
            // 
            this.pictureBox29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox29.Location = new System.Drawing.Point(497, 65);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(25, 25);
            this.pictureBox29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox29.TabIndex = 54;
            this.pictureBox29.TabStop = false;
            this.pictureBox29.Tag = "";
            this.pictureBox29.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox28
            // 
            this.pictureBox28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox28.Location = new System.Drawing.Point(463, 36);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(25, 25);
            this.pictureBox28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox28.TabIndex = 54;
            this.pictureBox28.TabStop = false;
            this.pictureBox28.Tag = "";
            this.pictureBox28.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox27
            // 
            this.pictureBox27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox27.Location = new System.Drawing.Point(463, 65);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(25, 25);
            this.pictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox27.TabIndex = 54;
            this.pictureBox27.TabStop = false;
            this.pictureBox27.Tag = "";
            this.pictureBox27.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox26
            // 
            this.pictureBox26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox26.Location = new System.Drawing.Point(429, 36);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(25, 25);
            this.pictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox26.TabIndex = 54;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.Tag = "";
            this.pictureBox26.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox25
            // 
            this.pictureBox25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox25.Location = new System.Drawing.Point(429, 65);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(25, 25);
            this.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox25.TabIndex = 54;
            this.pictureBox25.TabStop = false;
            this.pictureBox25.Tag = "";
            this.pictureBox25.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox24
            // 
            this.pictureBox24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox24.Location = new System.Drawing.Point(394, 36);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(25, 25);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox24.TabIndex = 54;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.Tag = "";
            this.pictureBox24.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox23
            // 
            this.pictureBox23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox23.Location = new System.Drawing.Point(394, 65);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(25, 25);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox23.TabIndex = 54;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.Tag = "";
            this.pictureBox23.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox22
            // 
            this.pictureBox22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox22.Location = new System.Drawing.Point(361, 36);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(25, 25);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox22.TabIndex = 54;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.Tag = "";
            this.pictureBox22.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox21
            // 
            this.pictureBox21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox21.Location = new System.Drawing.Point(361, 65);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(25, 25);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox21.TabIndex = 54;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Tag = "";
            this.pictureBox21.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox20
            // 
            this.pictureBox20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox20.Location = new System.Drawing.Point(326, 36);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(25, 25);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox20.TabIndex = 54;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Tag = "";
            this.pictureBox20.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox19
            // 
            this.pictureBox19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox19.Location = new System.Drawing.Point(326, 65);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(25, 25);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox19.TabIndex = 54;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Tag = "";
            this.pictureBox19.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox18
            // 
            this.pictureBox18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox18.Location = new System.Drawing.Point(239, 36);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(25, 25);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 54;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Tag = "";
            this.pictureBox18.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox17
            // 
            this.pictureBox17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox17.Location = new System.Drawing.Point(239, 65);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(25, 25);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 54;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Tag = "";
            this.pictureBox17.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox16
            // 
            this.pictureBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox16.Location = new System.Drawing.Point(198, 36);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(25, 25);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 54;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Tag = "";
            this.pictureBox16.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox15
            // 
            this.pictureBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox15.Location = new System.Drawing.Point(198, 65);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(25, 25);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 54;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Tag = "";
            this.pictureBox15.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox14
            // 
            this.pictureBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox14.Location = new System.Drawing.Point(158, 36);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(25, 25);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 54;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Tag = "";
            this.pictureBox14.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox13
            // 
            this.pictureBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox13.Location = new System.Drawing.Point(158, 65);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(25, 25);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 54;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Tag = "";
            this.pictureBox13.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox12.Location = new System.Drawing.Point(118, 36);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(25, 25);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 54;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Tag = "";
            this.pictureBox12.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox11.Location = new System.Drawing.Point(118, 65);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(25, 25);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 54;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Tag = "";
            this.pictureBox11.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox10.Location = new System.Drawing.Point(78, 36);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(25, 25);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 54;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Tag = "";
            this.pictureBox10.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox9.Location = new System.Drawing.Point(78, 65);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(25, 25);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 54;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Tag = "";
            this.pictureBox9.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox8.Location = new System.Drawing.Point(468, 135);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(50, 50);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 54;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Tag = "";
            this.pictureBox8.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Location = new System.Drawing.Point(412, 135);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(50, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 54;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Tag = "";
            this.pictureBox7.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox6.Location = new System.Drawing.Point(357, 135);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 54;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Tag = "";
            this.pictureBox6.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Location = new System.Drawing.Point(301, 135);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 50);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 54;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Tag = "";
            this.pictureBox5.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Location = new System.Drawing.Point(245, 135);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 54;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Tag = "";
            this.pictureBox4.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Location = new System.Drawing.Point(189, 135);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(50, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 54;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Tag = "";
            this.pictureBox3.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(133, 135);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 54;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Tag = "";
            this.pictureBox2.Click += new System.EventHandler(this.koltukSec_Click);
            // 
            // SuitOtobus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 402);
            this.Controls.Add(this.btnDevamEt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grpSuitOtobus);
            this.Name = "SuitOtobus";
            this.Text = "Suit Tip Otobüs";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.IkinciOtobus_FormClosed);
            this.Load += new System.EventHandler(this.IkinciOtobus_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxErkek)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKadin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grpSuitOtobus.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Button btnDevamEt;
        public System.Windows.Forms.Label lblOrtaKapi;
        public System.Windows.Forms.Label lblOnKapi;
        public System.Windows.Forms.Label lblSofor;
        public System.Windows.Forms.Label label43;
        public System.Windows.Forms.Label lblSecili;
        public System.Windows.Forms.Label label47;
        public System.Windows.Forms.Label label48;
        public System.Windows.Forms.Label label49;
        public System.Windows.Forms.Label label44;
        public System.Windows.Forms.PictureBox pictureBoxErkek;
        public System.Windows.Forms.PictureBox pictureBoxKadin;
        public System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.GroupBox grpSuitOtobus;
        public System.Windows.Forms.PictureBox pictureBox28;
        public System.Windows.Forms.PictureBox pictureBox27;
        public System.Windows.Forms.PictureBox pictureBox26;
        public System.Windows.Forms.PictureBox pictureBox25;
        public System.Windows.Forms.PictureBox pictureBox24;
        public System.Windows.Forms.PictureBox pictureBox23;
        public System.Windows.Forms.PictureBox pictureBox22;
        public System.Windows.Forms.PictureBox pictureBox21;
        public System.Windows.Forms.PictureBox pictureBox20;
        public System.Windows.Forms.PictureBox pictureBox19;
        public System.Windows.Forms.PictureBox pictureBox18;
        public System.Windows.Forms.PictureBox pictureBox17;
        public System.Windows.Forms.PictureBox pictureBox16;
        public System.Windows.Forms.PictureBox pictureBox15;
        public System.Windows.Forms.PictureBox pictureBox14;
        public System.Windows.Forms.PictureBox pictureBox13;
        public System.Windows.Forms.PictureBox pictureBox12;
        public System.Windows.Forms.PictureBox pictureBox11;
        public System.Windows.Forms.PictureBox pictureBox10;
        public System.Windows.Forms.PictureBox pictureBox9;
        public System.Windows.Forms.PictureBox pictureBox8;
        public System.Windows.Forms.PictureBox pictureBox7;
        public System.Windows.Forms.PictureBox pictureBox6;
        public System.Windows.Forms.PictureBox pictureBox5;
        public System.Windows.Forms.PictureBox pictureBox4;
        public System.Windows.Forms.PictureBox pictureBox3;
        public System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.PictureBox pictureBox30;
        public System.Windows.Forms.PictureBox pictureBox29;
    }
}
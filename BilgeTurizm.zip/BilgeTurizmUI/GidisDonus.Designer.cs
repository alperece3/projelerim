﻿namespace BilgeTurizmUI
{
    partial class GidisDonus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAnaSayfa = new System.Windows.Forms.Button();
            this.grpDonusSeferleri = new System.Windows.Forms.GroupBox();
            this.rdbDonusSeferSuit = new System.Windows.Forms.RadioButton();
            this.rdbDonusSeferStandart = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.grpDonusSeferSuit = new System.Windows.Forms.GroupBox();
            this.lblSuitDonus = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.grpDonusSeferPre = new System.Windows.Forms.GroupBox();
            this.lblStandartDonus = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.grpGidisSeferleri = new System.Windows.Forms.GroupBox();
            this.rdbGidisSeferSuit = new System.Windows.Forms.RadioButton();
            this.rdbGidisSeferStandart = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.grpGidisSeferSuit = new System.Windows.Forms.GroupBox();
            this.lblSuitGidis = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.grpGidisSeferPre = new System.Windows.Forms.GroupBox();
            this.lblStandartGidis = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.btnSeferSec = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblKampanya = new System.Windows.Forms.Label();
            this.lblKampanyaDonus = new System.Windows.Forms.Label();
            this.grpDonusSeferleri.SuspendLayout();
            this.grpDonusSeferSuit.SuspendLayout();
            this.grpDonusSeferPre.SuspendLayout();
            this.grpGidisSeferleri.SuspendLayout();
            this.grpGidisSeferSuit.SuspendLayout();
            this.grpGidisSeferPre.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAnaSayfa
            // 
            this.btnAnaSayfa.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnAnaSayfa.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAnaSayfa.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAnaSayfa.Location = new System.Drawing.Point(9, 528);
            this.btnAnaSayfa.Margin = new System.Windows.Forms.Padding(2);
            this.btnAnaSayfa.Name = "btnAnaSayfa";
            this.btnAnaSayfa.Size = new System.Drawing.Size(184, 45);
            this.btnAnaSayfa.TabIndex = 35;
            this.btnAnaSayfa.Text = "ANA SAYFAYA DÖN";
            this.btnAnaSayfa.UseVisualStyleBackColor = false;
            this.btnAnaSayfa.Click += new System.EventHandler(this.btnAnaSayfa_Click);
            // 
            // grpDonusSeferleri
            // 
            this.grpDonusSeferleri.Controls.Add(this.rdbDonusSeferSuit);
            this.grpDonusSeferleri.Controls.Add(this.rdbDonusSeferStandart);
            this.grpDonusSeferleri.Controls.Add(this.label9);
            this.grpDonusSeferleri.Controls.Add(this.label10);
            this.grpDonusSeferleri.Controls.Add(this.grpDonusSeferSuit);
            this.grpDonusSeferleri.Controls.Add(this.label17);
            this.grpDonusSeferleri.Controls.Add(this.grpDonusSeferPre);
            this.grpDonusSeferleri.Location = new System.Drawing.Point(5, 302);
            this.grpDonusSeferleri.Margin = new System.Windows.Forms.Padding(2);
            this.grpDonusSeferleri.Name = "grpDonusSeferleri";
            this.grpDonusSeferleri.Padding = new System.Windows.Forms.Padding(2);
            this.grpDonusSeferleri.Size = new System.Drawing.Size(456, 175);
            this.grpDonusSeferleri.TabIndex = 34;
            this.grpDonusSeferleri.TabStop = false;
            // 
            // rdbDonusSeferSuit
            // 
            this.rdbDonusSeferSuit.AutoSize = true;
            this.rdbDonusSeferSuit.Location = new System.Drawing.Point(11, 119);
            this.rdbDonusSeferSuit.Margin = new System.Windows.Forms.Padding(2);
            this.rdbDonusSeferSuit.Name = "rdbDonusSeferSuit";
            this.rdbDonusSeferSuit.Size = new System.Drawing.Size(14, 13);
            this.rdbDonusSeferSuit.TabIndex = 26;
            this.rdbDonusSeferSuit.TabStop = true;
            this.rdbDonusSeferSuit.UseVisualStyleBackColor = true;
            // 
            // rdbDonusSeferStandart
            // 
            this.rdbDonusSeferStandart.AutoSize = true;
            this.rdbDonusSeferStandart.Location = new System.Drawing.Point(11, 53);
            this.rdbDonusSeferStandart.Margin = new System.Windows.Forms.Padding(2);
            this.rdbDonusSeferStandart.Name = "rdbDonusSeferStandart";
            this.rdbDonusSeferStandart.Size = new System.Drawing.Size(14, 13);
            this.rdbDonusSeferStandart.TabIndex = 25;
            this.rdbDonusSeferStandart.TabStop = true;
            this.rdbDonusSeferStandart.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Lucida Sans Unicode", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.Navy;
            this.label9.Location = new System.Drawing.Point(368, 15);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 18);
            this.label9.TabIndex = 12;
            this.label9.Text = "FİYAT";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Lucida Sans Unicode", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.Navy;
            this.label10.Location = new System.Drawing.Point(182, 15);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(117, 18);
            this.label10.TabIndex = 11;
            this.label10.Text = "KALKIŞ SAATİ";
            // 
            // grpDonusSeferSuit
            // 
            this.grpDonusSeferSuit.BackColor = System.Drawing.Color.Gainsboro;
            this.grpDonusSeferSuit.Controls.Add(this.lblSuitDonus);
            this.grpDonusSeferSuit.Controls.Add(this.label15);
            this.grpDonusSeferSuit.Controls.Add(this.label16);
            this.grpDonusSeferSuit.Location = new System.Drawing.Point(38, 101);
            this.grpDonusSeferSuit.Margin = new System.Windows.Forms.Padding(2);
            this.grpDonusSeferSuit.Name = "grpDonusSeferSuit";
            this.grpDonusSeferSuit.Padding = new System.Windows.Forms.Padding(2);
            this.grpDonusSeferSuit.Size = new System.Drawing.Size(418, 62);
            this.grpDonusSeferSuit.TabIndex = 10;
            this.grpDonusSeferSuit.TabStop = false;
            // 
            // lblSuitDonus
            // 
            this.lblSuitDonus.AutoSize = true;
            this.lblSuitDonus.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSuitDonus.ForeColor = System.Drawing.Color.Navy;
            this.lblSuitDonus.Location = new System.Drawing.Point(331, 15);
            this.lblSuitDonus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSuitDonus.Name = "lblSuitDonus";
            this.lblSuitDonus.Size = new System.Drawing.Size(66, 17);
            this.lblSuitDonus.TabIndex = 9;
            this.lblSuitDonus.Text = "90+5 TL";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.ForeColor = System.Drawing.Color.Navy;
            this.label15.Location = new System.Drawing.Point(176, 15);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 17);
            this.label15.TabIndex = 8;
            this.label15.Text = "13:00";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.ForeColor = System.Drawing.Color.Navy;
            this.label16.Location = new System.Drawing.Point(5, 15);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(34, 17);
            this.label16.TabIndex = 7;
            this.label16.Text = "Suit";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Lucida Sans Unicode", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.ForeColor = System.Drawing.Color.Navy;
            this.label17.Location = new System.Drawing.Point(35, 15);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(75, 18);
            this.label17.TabIndex = 10;
            this.label17.Text = "OTOBÜS";
            // 
            // grpDonusSeferPre
            // 
            this.grpDonusSeferPre.BackColor = System.Drawing.Color.White;
            this.grpDonusSeferPre.Controls.Add(this.lblStandartDonus);
            this.grpDonusSeferPre.Controls.Add(this.label19);
            this.grpDonusSeferPre.Controls.Add(this.label20);
            this.grpDonusSeferPre.Location = new System.Drawing.Point(38, 34);
            this.grpDonusSeferPre.Margin = new System.Windows.Forms.Padding(2);
            this.grpDonusSeferPre.Name = "grpDonusSeferPre";
            this.grpDonusSeferPre.Padding = new System.Windows.Forms.Padding(2);
            this.grpDonusSeferPre.Size = new System.Drawing.Size(418, 62);
            this.grpDonusSeferPre.TabIndex = 9;
            this.grpDonusSeferPre.TabStop = false;
            // 
            // lblStandartDonus
            // 
            this.lblStandartDonus.AutoSize = true;
            this.lblStandartDonus.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStandartDonus.ForeColor = System.Drawing.Color.Navy;
            this.lblStandartDonus.Location = new System.Drawing.Point(331, 15);
            this.lblStandartDonus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStandartDonus.Name = "lblStandartDonus";
            this.lblStandartDonus.Size = new System.Drawing.Size(46, 17);
            this.lblStandartDonus.TabIndex = 5;
            this.lblStandartDonus.Text = "70 TL";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.ForeColor = System.Drawing.Color.Navy;
            this.label19.Location = new System.Drawing.Point(176, 15);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(48, 17);
            this.label19.TabIndex = 4;
            this.label19.Text = "11:00";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.ForeColor = System.Drawing.Color.Navy;
            this.label20.Location = new System.Drawing.Point(4, 15);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(66, 17);
            this.label20.TabIndex = 3;
            this.label20.Text = "Standart";
            // 
            // grpGidisSeferleri
            // 
            this.grpGidisSeferleri.Controls.Add(this.rdbGidisSeferSuit);
            this.grpGidisSeferleri.Controls.Add(this.rdbGidisSeferStandart);
            this.grpGidisSeferleri.Controls.Add(this.label4);
            this.grpGidisSeferleri.Controls.Add(this.label3);
            this.grpGidisSeferleri.Controls.Add(this.grpGidisSeferSuit);
            this.grpGidisSeferleri.Controls.Add(this.label2);
            this.grpGidisSeferleri.Controls.Add(this.grpGidisSeferPre);
            this.grpGidisSeferleri.Location = new System.Drawing.Point(9, 44);
            this.grpGidisSeferleri.Margin = new System.Windows.Forms.Padding(2);
            this.grpGidisSeferleri.Name = "grpGidisSeferleri";
            this.grpGidisSeferleri.Padding = new System.Windows.Forms.Padding(2);
            this.grpGidisSeferleri.Size = new System.Drawing.Size(452, 175);
            this.grpGidisSeferleri.TabIndex = 33;
            this.grpGidisSeferleri.TabStop = false;
            // 
            // rdbGidisSeferSuit
            // 
            this.rdbGidisSeferSuit.AutoSize = true;
            this.rdbGidisSeferSuit.Location = new System.Drawing.Point(11, 127);
            this.rdbGidisSeferSuit.Margin = new System.Windows.Forms.Padding(2);
            this.rdbGidisSeferSuit.Name = "rdbGidisSeferSuit";
            this.rdbGidisSeferSuit.Size = new System.Drawing.Size(14, 13);
            this.rdbGidisSeferSuit.TabIndex = 24;
            this.rdbGidisSeferSuit.TabStop = true;
            this.rdbGidisSeferSuit.UseVisualStyleBackColor = true;
            // 
            // rdbGidisSeferStandart
            // 
            this.rdbGidisSeferStandart.AutoSize = true;
            this.rdbGidisSeferStandart.Location = new System.Drawing.Point(11, 60);
            this.rdbGidisSeferStandart.Margin = new System.Windows.Forms.Padding(2);
            this.rdbGidisSeferStandart.Name = "rdbGidisSeferStandart";
            this.rdbGidisSeferStandart.Size = new System.Drawing.Size(14, 13);
            this.rdbGidisSeferStandart.TabIndex = 23;
            this.rdbGidisSeferStandart.TabStop = true;
            this.rdbGidisSeferStandart.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Sans Unicode", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.Navy;
            this.label4.Location = new System.Drawing.Point(368, 15);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 18);
            this.label4.TabIndex = 12;
            this.label4.Text = "FİYAT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Sans Unicode", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.Navy;
            this.label3.Location = new System.Drawing.Point(182, 15);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 18);
            this.label3.TabIndex = 11;
            this.label3.Text = "KALKIŞ SAATİ";
            // 
            // grpGidisSeferSuit
            // 
            this.grpGidisSeferSuit.BackColor = System.Drawing.Color.Gainsboro;
            this.grpGidisSeferSuit.Controls.Add(this.lblSuitGidis);
            this.grpGidisSeferSuit.Controls.Add(this.label12);
            this.grpGidisSeferSuit.Controls.Add(this.label13);
            this.grpGidisSeferSuit.Location = new System.Drawing.Point(38, 101);
            this.grpGidisSeferSuit.Margin = new System.Windows.Forms.Padding(2);
            this.grpGidisSeferSuit.Name = "grpGidisSeferSuit";
            this.grpGidisSeferSuit.Padding = new System.Windows.Forms.Padding(2);
            this.grpGidisSeferSuit.Size = new System.Drawing.Size(414, 62);
            this.grpGidisSeferSuit.TabIndex = 10;
            this.grpGidisSeferSuit.TabStop = false;
            // 
            // lblSuitGidis
            // 
            this.lblSuitGidis.AutoSize = true;
            this.lblSuitGidis.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSuitGidis.ForeColor = System.Drawing.Color.Navy;
            this.lblSuitGidis.Location = new System.Drawing.Point(331, 15);
            this.lblSuitGidis.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSuitGidis.Name = "lblSuitGidis";
            this.lblSuitGidis.Size = new System.Drawing.Size(66, 17);
            this.lblSuitGidis.TabIndex = 9;
            this.lblSuitGidis.Text = "90+5 TL";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.Navy;
            this.label12.Location = new System.Drawing.Point(176, 15);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 17);
            this.label12.TabIndex = 8;
            this.label12.Text = "13:00";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.Navy;
            this.label13.Location = new System.Drawing.Point(5, 15);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 17);
            this.label13.TabIndex = 7;
            this.label13.Text = "Suit";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.Navy;
            this.label2.Location = new System.Drawing.Point(35, 15);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 18);
            this.label2.TabIndex = 10;
            this.label2.Text = "OTOBÜS";
            // 
            // grpGidisSeferPre
            // 
            this.grpGidisSeferPre.BackColor = System.Drawing.Color.White;
            this.grpGidisSeferPre.Controls.Add(this.lblStandartGidis);
            this.grpGidisSeferPre.Controls.Add(this.label6);
            this.grpGidisSeferPre.Controls.Add(this.Label5);
            this.grpGidisSeferPre.Location = new System.Drawing.Point(38, 34);
            this.grpGidisSeferPre.Margin = new System.Windows.Forms.Padding(2);
            this.grpGidisSeferPre.Name = "grpGidisSeferPre";
            this.grpGidisSeferPre.Padding = new System.Windows.Forms.Padding(2);
            this.grpGidisSeferPre.Size = new System.Drawing.Size(414, 62);
            this.grpGidisSeferPre.TabIndex = 9;
            this.grpGidisSeferPre.TabStop = false;
            // 
            // lblStandartGidis
            // 
            this.lblStandartGidis.AutoSize = true;
            this.lblStandartGidis.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStandartGidis.ForeColor = System.Drawing.Color.Navy;
            this.lblStandartGidis.Location = new System.Drawing.Point(331, 15);
            this.lblStandartGidis.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStandartGidis.Name = "lblStandartGidis";
            this.lblStandartGidis.Size = new System.Drawing.Size(46, 17);
            this.lblStandartGidis.TabIndex = 5;
            this.lblStandartGidis.Text = "70 TL";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.Navy;
            this.label6.Location = new System.Drawing.Point(176, 15);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 17);
            this.label6.TabIndex = 4;
            this.label6.Text = "11:00";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Label5.ForeColor = System.Drawing.Color.Navy;
            this.Label5.Location = new System.Drawing.Point(4, 15);
            this.Label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(66, 17);
            this.Label5.TabIndex = 3;
            this.Label5.Text = "Standart";
            // 
            // btnSeferSec
            // 
            this.btnSeferSec.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnSeferSec.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSeferSec.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSeferSec.Location = new System.Drawing.Point(327, 528);
            this.btnSeferSec.Margin = new System.Windows.Forms.Padding(2);
            this.btnSeferSec.Name = "btnSeferSec";
            this.btnSeferSec.Size = new System.Drawing.Size(134, 45);
            this.btnSeferSec.TabIndex = 32;
            this.btnSeferSec.Text = "KOLTUK SEÇİMİ";
            this.btnSeferSec.UseVisualStyleBackColor = false;
            this.btnSeferSec.Click += new System.EventHandler(this.btnSeferSec_Click);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.label8.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(9, 275);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(452, 24);
            this.label8.TabIndex = 31;
            this.label8.Text = "Dönüş Seferleri:";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(16, 17);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(445, 24);
            this.label1.TabIndex = 30;
            this.label1.Text = "Gidiş Seferleri:";
            // 
            // lblKampanya
            // 
            this.lblKampanya.AutoSize = true;
            this.lblKampanya.BackColor = System.Drawing.SystemColors.Control;
            this.lblKampanya.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKampanya.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblKampanya.Location = new System.Drawing.Point(12, 230);
            this.lblKampanya.Name = "lblKampanya";
            this.lblKampanya.Size = new System.Drawing.Size(436, 15);
            this.lblKampanya.TabIndex = 36;
            this.lblKampanya.Text = "Seçtiğiniz sefer ve tarihe özel Suit otobüsümüzde kampanya vardır.";
            this.lblKampanya.Visible = false;
            // 
            // lblKampanyaDonus
            // 
            this.lblKampanyaDonus.AutoSize = true;
            this.lblKampanyaDonus.BackColor = System.Drawing.SystemColors.Control;
            this.lblKampanyaDonus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKampanyaDonus.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblKampanyaDonus.Location = new System.Drawing.Point(17, 491);
            this.lblKampanyaDonus.Name = "lblKampanyaDonus";
            this.lblKampanyaDonus.Size = new System.Drawing.Size(436, 15);
            this.lblKampanyaDonus.TabIndex = 37;
            this.lblKampanyaDonus.Text = "Seçtiğiniz sefer ve tarihe özel Suit otobüsümüzde kampanya vardır.";
            this.lblKampanyaDonus.Visible = false;
            // 
            // GidisDonus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(474, 584);
            this.Controls.Add(this.lblKampanyaDonus);
            this.Controls.Add(this.lblKampanya);
            this.Controls.Add(this.btnAnaSayfa);
            this.Controls.Add(this.grpDonusSeferleri);
            this.Controls.Add(this.grpGidisSeferleri);
            this.Controls.Add(this.btnSeferSec);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label1);
            this.Name = "GidisDonus";
            this.Text = "Gidiş Dönüş Seferleri";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.GidisDonus_FormClosed);
            this.Load += new System.EventHandler(this.GidisDonus_Load);
            this.grpDonusSeferleri.ResumeLayout(false);
            this.grpDonusSeferleri.PerformLayout();
            this.grpDonusSeferSuit.ResumeLayout(false);
            this.grpDonusSeferSuit.PerformLayout();
            this.grpDonusSeferPre.ResumeLayout(false);
            this.grpDonusSeferPre.PerformLayout();
            this.grpGidisSeferleri.ResumeLayout(false);
            this.grpGidisSeferleri.PerformLayout();
            this.grpGidisSeferSuit.ResumeLayout(false);
            this.grpGidisSeferSuit.PerformLayout();
            this.grpGidisSeferPre.ResumeLayout(false);
            this.grpGidisSeferPre.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btnAnaSayfa;
        public System.Windows.Forms.GroupBox grpDonusSeferleri;
        public System.Windows.Forms.RadioButton rdbDonusSeferSuit;
        public System.Windows.Forms.RadioButton rdbDonusSeferStandart;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.GroupBox grpDonusSeferSuit;
        public System.Windows.Forms.Label lblSuitDonus;
        public System.Windows.Forms.Label label15;
        public System.Windows.Forms.Label label16;
        public System.Windows.Forms.Label label17;
        public System.Windows.Forms.GroupBox grpDonusSeferPre;
        public System.Windows.Forms.Label lblStandartDonus;
        public System.Windows.Forms.Label label19;
        public System.Windows.Forms.Label label20;
        public System.Windows.Forms.GroupBox grpGidisSeferleri;
        public System.Windows.Forms.RadioButton rdbGidisSeferSuit;
        public System.Windows.Forms.RadioButton rdbGidisSeferStandart;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.GroupBox grpGidisSeferSuit;
        public System.Windows.Forms.Label lblSuitGidis;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.GroupBox grpGidisSeferPre;
        public System.Windows.Forms.Label lblStandartGidis;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label Label5;
        public System.Windows.Forms.Button btnSeferSec;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblKampanya;
        private System.Windows.Forms.Label lblKampanyaDonus;
    }
}


﻿namespace BilgeTurizmUI
{
    partial class OzetEkrani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBitir = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ozetPaneli = new System.Windows.Forms.FlowLayoutPanel();
            this.lblOdemeText = new System.Windows.Forms.Label();
            this.lblToplamUcret = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblPnrKodu = new System.Windows.Forms.Label();
            this.lblBilet = new System.Windows.Forms.Label();
            this.lblBiletUcreti = new System.Windows.Forms.Label();
            this.lblSigorta = new System.Windows.Forms.Label();
            this.lblSigortaUcreti = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(18, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 19);
            this.label1.TabIndex = 39;
            this.label1.Text = "Ad Soyad";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(578, 45);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 19);
            this.label12.TabIndex = 40;
            this.label12.Text = "Bilet Sınıfı";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(498, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 19);
            this.label5.TabIndex = 41;
            this.label5.Text = "Koltuk No";
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.label9.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(11, 9);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(808, 24);
            this.label9.TabIndex = 51;
            this.label9.Text = "Seyahat Bilgileri";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(108, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 19);
            this.label2.TabIndex = 42;
            this.label2.Text = "TC No";
            // 
            // btnBitir
            // 
            this.btnBitir.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnBitir.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBitir.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBitir.Location = new System.Drawing.Point(671, 391);
            this.btnBitir.Margin = new System.Windows.Forms.Padding(2);
            this.btnBitir.Name = "btnBitir";
            this.btnBitir.Size = new System.Drawing.Size(148, 43);
            this.btnBitir.TabIndex = 50;
            this.btnBitir.Text = "BİTİR";
            this.btnBitir.UseVisualStyleBackColor = false;
            this.btnBitir.Click += new System.EventHandler(this.btnBitir_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(175, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 19);
            this.label3.TabIndex = 43;
            this.label3.Text = "Nereden";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(258, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 19);
            this.label4.TabIndex = 44;
            this.label4.Text = "Nereye";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(418, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 19);
            this.label7.TabIndex = 45;
            this.label7.Text = "Sefer Saati";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(338, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 19);
            this.label6.TabIndex = 46;
            this.label6.Text = "Sefer Tarihi";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(749, 45);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 19);
            this.label10.TabIndex = 47;
            this.label10.Text = "Yemek";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(658, 45);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 19);
            this.label8.TabIndex = 48;
            this.label8.Text = "Otobüs Tipi";
            // 
            // ozetPaneli
            // 
            this.ozetPaneli.AutoScroll = true;
            this.ozetPaneli.Location = new System.Drawing.Point(15, 79);
            this.ozetPaneli.Name = "ozetPaneli";
            this.ozetPaneli.Size = new System.Drawing.Size(804, 266);
            this.ozetPaneli.TabIndex = 49;
            // 
            // lblOdemeText
            // 
            this.lblOdemeText.AutoSize = true;
            this.lblOdemeText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOdemeText.Location = new System.Drawing.Point(11, 402);
            this.lblOdemeText.Name = "lblOdemeText";
            this.lblOdemeText.Size = new System.Drawing.Size(126, 20);
            this.lblOdemeText.TabIndex = 52;
            this.lblOdemeText.Text = "Toplam Ücret: ";
            // 
            // lblToplamUcret
            // 
            this.lblToplamUcret.AutoSize = true;
            this.lblToplamUcret.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblToplamUcret.Location = new System.Drawing.Point(143, 402);
            this.lblToplamUcret.Name = "lblToplamUcret";
            this.lblToplamUcret.Size = new System.Drawing.Size(64, 20);
            this.lblToplamUcret.TabIndex = 52;
            this.lblToplamUcret.Text = "### TL";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(323, 402);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(117, 20);
            this.label11.TabIndex = 53;
            this.label11.Text = "PNR Kodunuz: ";
            // 
            // lblPnrKodu
            // 
            this.lblPnrKodu.AutoSize = true;
            this.lblPnrKodu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPnrKodu.Location = new System.Drawing.Point(445, 402);
            this.lblPnrKodu.Name = "lblPnrKodu";
            this.lblPnrKodu.Size = new System.Drawing.Size(74, 20);
            this.lblPnrKodu.TabIndex = 53;
            this.lblPnrKodu.Text = "pnrkodu";
            // 
            // lblBilet
            // 
            this.lblBilet.AutoSize = true;
            this.lblBilet.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBilet.Location = new System.Drawing.Point(50, 382);
            this.lblBilet.Name = "lblBilet";
            this.lblBilet.Size = new System.Drawing.Size(87, 18);
            this.lblBilet.TabIndex = 52;
            this.lblBilet.Text = "Bilet Ücreti: ";
            this.lblBilet.Visible = false;
            // 
            // lblBiletUcreti
            // 
            this.lblBiletUcreti.AutoSize = true;
            this.lblBiletUcreti.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBiletUcreti.Location = new System.Drawing.Point(143, 382);
            this.lblBiletUcreti.Name = "lblBiletUcreti";
            this.lblBiletUcreti.Size = new System.Drawing.Size(53, 18);
            this.lblBiletUcreti.TabIndex = 52;
            this.lblBiletUcreti.Text = "### TL";
            this.lblBiletUcreti.Visible = false;
            // 
            // lblSigorta
            // 
            this.lblSigorta.AutoSize = true;
            this.lblSigorta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSigorta.Location = new System.Drawing.Point(31, 364);
            this.lblSigorta.Name = "lblSigorta";
            this.lblSigorta.Size = new System.Drawing.Size(106, 18);
            this.lblSigorta.TabIndex = 52;
            this.lblSigorta.Text = "Sigorta Ücreti: ";
            this.lblSigorta.Visible = false;
            // 
            // lblSigortaUcreti
            // 
            this.lblSigortaUcreti.AutoSize = true;
            this.lblSigortaUcreti.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSigortaUcreti.Location = new System.Drawing.Point(143, 364);
            this.lblSigortaUcreti.Name = "lblSigortaUcreti";
            this.lblSigortaUcreti.Size = new System.Drawing.Size(53, 18);
            this.lblSigortaUcreti.TabIndex = 52;
            this.lblSigortaUcreti.Text = "### TL";
            this.lblSigortaUcreti.Visible = false;
            // 
            // OzetEkrani
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(839, 444);
            this.Controls.Add(this.lblPnrKodu);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lblSigortaUcreti);
            this.Controls.Add(this.lblBiletUcreti);
            this.Controls.Add(this.lblToplamUcret);
            this.Controls.Add(this.lblSigorta);
            this.Controls.Add(this.lblBilet);
            this.Controls.Add(this.lblOdemeText);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnBitir);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.ozetPaneli);
            this.Name = "OzetEkrani";
            this.Text = "Özet Bilgi Ekranı";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.OzetEkrani_FormClosed);
            this.Load += new System.EventHandler(this.OzetEkrani_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.Button btnBitir;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.FlowLayoutPanel ozetPaneli;
        private System.Windows.Forms.Label lblOdemeText;
        private System.Windows.Forms.Label lblToplamUcret;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblPnrKodu;
        private System.Windows.Forms.Label lblBilet;
        private System.Windows.Forms.Label lblBiletUcreti;
        private System.Windows.Forms.Label lblSigorta;
        private System.Windows.Forms.Label lblSigortaUcreti;
    }
}